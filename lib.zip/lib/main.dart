// ignore_for_file: unused_import

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:profit_from_it_investors/provider/analytics_provider/analytics_provider.dart';
import 'package:profit_from_it_investors/provider/app_update_provider/app_update_provider.dart';
import 'package:profit_from_it_investors/provider/authentication/auth_provider.dart';
import 'package:profit_from_it_investors/provider/authentication/profile_provider.dart';
import 'package:profit_from_it_investors/provider/authentication/user_provider.dart';
import 'package:profit_from_it_investors/provider/client_switch/client_switch_provider.dart';
import 'package:profit_from_it_investors/provider/family/family_provider.dart';
import 'package:profit_from_it_investors/provider/holdings/holdings_provider.dart';
import 'package:profit_from_it_investors/provider/home/home_provider.dart';
import 'package:profit_from_it_investors/provider/net_contribution_provider/net_contribution_provider.dart';
import 'package:profit_from_it_investors/provider/notification_provider/notification_provider.dart';
import 'package:profit_from_it_investors/provider/dividend_provider/dividend_provider.dart';
import 'package:profit_from_it_investors/provider/stock_detail/stock_detail_provider.dart';
import 'package:profit_from_it_investors/provider/taxometer/taxometer_provider.dart';
import 'package:profit_from_it_investors/provider/transaction_provider/transaction_provider.dart';
import 'package:profit_from_it_investors/provider/watchlist_provider/watchlist_provider.dart';
import 'package:profit_from_it_investors/theme/app_theme.dart';
import 'package:profit_from_it_investors/ui/splash_screen/splash_screen.dart';
import 'package:profit_from_it_investors/ui/support_messages/support_messages_screen.dart';
import 'package:profit_from_it_investors/utility/common.dart';
import 'package:profit_from_it_investors/utility/constant.dart';
import 'package:profit_from_it_investors/utility/session_manager.dart';
import 'package:profit_from_it_investors/utility/notification_service.dart';
import 'package:provider/provider.dart';

import 'package:timezone/data/latest.dart' as tz;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await NotificationService.initialize();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );

  await initializeDateFormatting();
  tz.initializeTimeZones();

  await SessionManager.initialize();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => ProfileProvider()),
        ChangeNotifierProvider(create: (_) => HomeProvider()),
        ChangeNotifierProvider(create: (_) => StockDetailProvider()),
        ChangeNotifierProvider(create: (_) => HoldingsProvider()),
        ChangeNotifierProvider(create: (_) => AnalyticsProvider()),
        ChangeNotifierProvider(create: (_) => AppUpdateProvider()),
        ChangeNotifierProvider(create: (_) => TaxometerProvider()),
        ChangeNotifierProvider(create: (_) => TransactionProvider()),
        ChangeNotifierProvider(create: (_) => WatchlistProvider()),
        ChangeNotifierProvider(create: (_) => FamilyProvider()),
        ChangeNotifierProvider(create: (_) => ClientSwitchProvider()),
        ChangeNotifierProvider(create: (_) => NetContributionProvider()),
        ChangeNotifierProvider(create: (_) => DividendProvider()),
        ChangeNotifierProvider(create: (_) => AppNotificationProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      child: MaterialApp(
        scaffoldMessengerKey: rootScaffoldMessengerKey,
        title: Constants.appName,
        navigatorKey: navigatorKey,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        home: SplashScreen(),
        onGenerateRoute: (settings) {
          if (settings.name == '/support-ticket') {
            final int? ticketId = settings.arguments is int
                ? settings.arguments as int
                : int.tryParse(settings.arguments?.toString() ?? '');

            return MaterialPageRoute(
              settings: settings,
              builder: (_) => SupportMessagesScreen(initialTicketId: ticketId),
            );
          }

          return null;
        },
      ),
    );
  }
}
