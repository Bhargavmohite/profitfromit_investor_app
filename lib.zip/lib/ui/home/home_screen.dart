import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:profit_from_it_investors/model/dashboard_response.dart';
import 'package:profit_from_it_investors/provider/authentication/profile_provider.dart';
import 'package:profit_from_it_investors/provider/authentication/user_provider.dart';
import 'package:profit_from_it_investors/provider/client_switch/client_switch_provider.dart';
import 'package:profit_from_it_investors/provider/family/family_provider.dart';
import 'package:profit_from_it_investors/provider/home/home_provider.dart';
import 'package:profit_from_it_investors/provider/notification_provider/notification_provider.dart';
import 'package:profit_from_it_investors/ui/stock_detail_screen/stock_detail_screen.dart';
import 'package:profit_from_it_investors/ui/net_contribution/net_contribution_screen.dart';
import 'package:profit_from_it_investors/ui/notifications/notifications_screen.dart';
import 'package:profit_from_it_investors/ui/dividend/dividend_screen.dart';
import 'package:profit_from_it_investors/utility/app_color.dart';
import 'package:profit_from_it_investors/utility/client_selection_bottom_sheet.dart';
import 'package:profit_from_it_investors/utility/common.dart';
import 'package:profit_from_it_investors/utility/family_selection_bottom_sheet.dart';
import 'package:profit_from_it_investors/utility/local_storage.dart';
import 'package:profit_from_it_investors/utility/session_manager.dart';
import 'package:provider/provider.dart';

enum _NominationDialogAction { later, addNow }

class HomeScreen extends StatefulWidget {
  final VoidCallback? onOpenMenu;
  final VoidCallback? onGoHome;
  final VoidCallback? onViewAllHoldings;
  final VoidCallback? onOpenAnalytics;
  final VoidCallback? onOpenTaxometer;
  final VoidCallback? onOpenMovers;
  final VoidCallback? onOpenProfile;
  final VoidCallback? onOpenSupportMessages;

  const HomeScreen({
    super.key,
    this.onOpenMenu,
    this.onGoHome,
    this.onViewAllHoldings,
    this.onOpenAnalytics,
    this.onOpenTaxometer,
    this.onOpenMovers,
    this.onOpenProfile,
    this.onOpenSupportMessages,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Set<String> _nominationChecksStarted = <String>{};

  String _nominationDayKey() {
    final now = DateTime.now();
    return '${now.year.toString().padLeft(4, '0')}-'
        '${now.month.toString().padLeft(2, '0')}-'
        '${now.day.toString().padLeft(2, '0')}';
  }

  void _scheduleNominationCheck({
    required int? activeClientId,
    required bool isAccountSwitching,
  }) {
    if (activeClientId == null || isAccountSwitching) {
      return;
    }

    final checkKey = '$activeClientId:${_nominationDayKey()}';
    if (_nominationChecksStarted.contains(checkKey)) {
      return;
    }

    _nominationChecksStarted.add(checkKey);

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) {
        return;
      }

      await _checkAndShowNominationPopup(
        activeClientId: activeClientId,
        checkKey: checkKey,
      );
    });
  }

  Future<void> _checkAndShowNominationPopup({
    required int activeClientId,
    required String checkKey,
  }) async {
    final userId = activeClientId.toString();

    // If the user switched again before this check started, do nothing.
    if (SessionManager.userId != userId) {
      _nominationChecksStarted.remove(checkKey);
      return;
    }

    final alreadyShown = await LocalStorage.wasNominationPromptShownToday(
      userId,
    );

    if (!mounted || SessionManager.userId != userId) {
      return;
    }

    if (alreadyShown) {
      return;
    }

    final profile = await context
        .read<ProfileProvider>()
        .getProfileDataSilently();

    if (!mounted || SessionManager.userId != userId) {
      return;
    }

    // If the profile request could not be completed, do not guess that the
    // user has no nominee. A later dashboard refresh / switch can retry.
    if (profile == null) {
      _nominationChecksStarted.remove(checkKey);
      return;
    }

    final hasNominee = profile.nominees?.isNotEmpty == true;
    if (hasNominee) {
      return;
    }

    // Mark it before opening the dialog so rebuilds cannot show the same
    // reminder twice on the same day for the same client.
    await LocalStorage.markNominationPromptShownToday(userId);

    if (!mounted || SessionManager.userId != userId) {
      return;
    }

    await _showNominationDialog();
  }

  Future<void> _showNominationDialog() async {
    final action = await showDialog<_NominationDialogAction>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24),
          child: Container(
            width: double.infinity,
            constraints: const BoxConstraints(maxWidth: 390),
            padding: const EdgeInsets.fromLTRB(22, 24, 22, 20),
            decoration: BoxDecoration(
              color: AppColor.surface,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.10),
                  blurRadius: 28,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppColor.primary.withValues(alpha: 0.10),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.person_add_alt_1_rounded,
                    color: AppColor.primary,
                    size: 31,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Add a Nominee',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColor.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Please kindly add a nominee to your account.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 12.5,
                    height: 1.55,
                    color: AppColor.textSecondary,
                  ),
                ),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.of(
                          dialogContext,
                        ).pop(_NominationDialogAction.later),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColor.textSecondary,
                          side: const BorderSide(color: AppColor.divider),
                          minimumSize: const Size.fromHeight(48),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: Text(
                          'Later',
                          style: GoogleFonts.poppins(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(
                            dialogContext,
                          ).pop(_NominationDialogAction.addNow);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColor.primary,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          minimumSize: const Size.fromHeight(48),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: Text(
                          'Add Now',
                          style: GoogleFonts.poppins(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );

    if (!mounted || action != _NominationDialogAction.addNow) {
      return;
    }

    // Do not push a new route while the dialog Overlay is still being
    // deactivated. Let the dialog route complete its teardown first, then
    // open Support Messages from the stable Home context.
    await Future<void>.delayed(const Duration(milliseconds: 250));

    if (!mounted) {
      return;
    }

    widget.onOpenSupportMessages?.call();
  }

  String _getSafeInitial(String? value) {
    final text = (value ?? '').trim();

    if (text.isEmpty) {
      return '?';
    }

    return text[0].toUpperCase();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final homeProvider = context.read<HomeProvider>();
      final notificationProvider = context.read<AppNotificationProvider>();

      // Load the unread notification count for the Home bell.
      // This is intentionally non-blocking so Home rendering is never delayed.
      notificationProvider.getNotifications(showLoader: false);

      // Load the dashboard first because it contains the information needed
      // to render Home. The chart is intentionally started afterwards without
      // blocking the rest of the screen.
      final dashboardLoaded = await homeProvider.getDashboard(context);

      if (mounted && dashboardLoaded) {
        homeProvider.loadPortfolioChartInBackground(context);
      }

      // Do NOT preload the full Holdings API here. Holdings are loaded by the
      // Holdings screen when the user actually opens that tab. Home already
      // receives Holdings / Gainers / Losers from the Dashboard response.
      if (mounted) {
        final familyProvider = context.read<FamilyProvider>();
        familyProvider.setFamilyList(
          homeProvider.dashboardData?.familyList ?? [],
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final homeProvider = context.watch<HomeProvider>();
    final clientSwitchState = context.watch<ClientSwitchProvider>();
    final familySwitchState = context.watch<FamilyProvider>();
    final dashboardData = homeProvider.dashboardData;

    final bool isAccountSwitching =
        clientSwitchState.isSwitching || familySwitchState.isSwitching;

    final String switchingAccountName = clientSwitchState.isSwitching
        ? (clientSwitchState.selectedClient?.name ?? '').trim()
        : familySwitchState.isSwitching
        ? (familySwitchState.selectedFamily?.name ?? '').trim()
        : '';

    final String switchingAccountCode = clientSwitchState.isSwitching
        ? (clientSwitchState.selectedClient?.ccode ?? '').trim()
        : '';

    _scheduleNominationCheck(
      activeClientId: dashboardData?.activeClientId,
      isAccountSwitching: isAccountSwitching,
    );

    // IMPORTANT:
    // Holdings / Gainers / Losers must come from the SAME Dashboard response.
    //
    // Previously:
    // - Holdings came from Dashboard API.
    // - Gainers / Losers came from HoldingsProvider.
    //
    // During user switching, Dashboard could already contain the NEW client
    // while HoldingsProvider still contained the OLD client's holdings. That
    // produced mixed counts such as 60 Holdings but 25 + 42 = 67.
    //
    // The backend now calculates all three counts from the same ACTIVE holdings
    // collection, so Home should render those atomic Dashboard values directly.

    return Scaffold(
      backgroundColor: AppColor.background,

      // Do not replace the entire Home screen with a blank spinner while
      // switching clients. Keep the last confirmed dashboard visible until
      // the destination dashboard arrives, then swap it atomically.
      //
      // This also allows the per-client chart cache in HomeProvider to become
      // visible immediately when a previously loaded client is selected.
      body: homeProvider.dashboardLoading && dashboardData == null
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: Column(
                children: [
                  Consumer3<UserProvider, FamilyProvider, ClientSwitchProvider>(
                    builder:
                        (
                          context,
                          userProvider,
                          familyProvider,
                          clientSwitchProvider,
                          _,
                        ) {
                          // Give immediate visual confirmation that the tap
                          // was accepted. While the destination dashboard is
                          // loading, show the selected account name in the
                          // header instead of leaving the old user's name there.
                          final name =
                              isAccountSwitching &&
                                  switchingAccountName.isNotEmpty
                              ? switchingAccountName
                              : (dashboardData?.name ?? userProvider.name);

                          // Family selector rule:
                          // - Master (is_family_master = 1) + family_id => SHOW
                          // - Non-master / no family_id => HIDE
                          //
                          // Do not depend on family_list length here. The family
                          // list is loaded by the dashboard API and displayed in
                          // the bottom sheet after the selector is opened.
                          final hasFamily =
                              dashboardData?.familyId != null &&
                              (dashboardData?.isFamilyMaster == 1 ||
                                  dashboardData?.canSelectFamily == true);

                          // Family selector keeps its existing priority.
                          //
                          // Supported client-switch modes:
                          //
                          // 1) Readonly Admin Client
                          //    ctype = Client + is_readonly_admin = 1
                          //    -> show "Switch User"
                          //
                          // 2) Partner
                          //    ctype = Partner
                          //    -> show "Switch Member"
                          //
                          // 3) Normal Client
                          //    -> no switching option
                          final accountCtype = (dashboardData?.ctype ?? '')
                              .trim()
                              .toLowerCase();

                          final isPartner = accountCtype == 'partner';

                          final isReadonlyAdminClient =
                              accountCtype == 'client' &&
                              dashboardData?.isReadonlyAdmin == 1;

                          // Switching permissions are independent from Family
                          // Master permission. If an account is both Family
                          // Master and Partner/Readonly Admin, show BOTH controls.
                          final showPartnerSwitch =
                              isPartner &&
                              dashboardData?.canSwitchClients == true &&
                              clientSwitchProvider.canShowSwitchMember;

                          final showReadonlyAdminSwitch =
                              isReadonlyAdminClient &&
                              dashboardData?.canSwitchClients == true &&
                              clientSwitchProvider.canShowSwitchUser;

                          final showClientSwitch =
                              showPartnerSwitch || showReadonlyAdminSwitch;

                          final clientSwitchLabel = showPartnerSwitch
                              ? 'Switch Member'
                              : 'Switch User';

                          // Time-based greeting using device local time.
                          final currentHour = DateTime.now().hour;

                          final String greeting;
                          if (currentHour >= 6 && currentHour < 12) {
                            greeting = 'Good Morning';
                          } else if (currentHour >= 12 && currentHour < 17) {
                            greeting = 'Good Afternoon';
                          } else if (currentHour >= 17 && currentHour < 19) {
                            greeting = 'Good Evening';
                          } else {
                            greeting = 'Hello';
                          }

                          return Container(
                            width: double.infinity,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              border: Border(
                                bottom: BorderSide(
                                  color: Color(0xFFF0F2F6),
                                  width: 1,
                                ),
                              ),
                            ),
                            padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    InkWell(
                                      borderRadius: BorderRadius.circular(12),
                                      onTap: widget.onOpenMenu,
                                      child: Container(
                                        width: 42,
                                        height: 42,
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFF6F8FC),
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                          border: Border.all(
                                            color: const Color(0xFFDDE4EF),
                                          ),
                                        ),
                                        alignment: Alignment.center,
                                        child: const Icon(
                                          Icons.menu_rounded,
                                          color: AppColor.textPrimary,
                                          size: 23,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            greeting,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: GoogleFonts.poppins(
                                              fontSize: 19,
                                              fontWeight: FontWeight.w700,
                                              color: AppColor.textPrimary,
                                              height: 1.2,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            'Welcome to Profit From It',
                                            style: GoogleFonts.poppins(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w400,
                                              color: AppColor.textSecondary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Consumer<AppNotificationProvider>(
                                      builder: (context, notificationProvider, _) {
                                        final unread =
                                            notificationProvider.unreadCount;

                                        return InkWell(
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                          onTap: () async {
                                            await Navigator.of(context).push(
                                              MaterialPageRoute(
                                                builder: (_) =>
                                                    const NotificationsScreen(),
                                              ),
                                            );

                                            if (context.mounted) {
                                              notificationProvider
                                                  .getNotifications(
                                                    showLoader: false,
                                                  );
                                            }
                                          },
                                          child: SizedBox(
                                            width: 44,
                                            height: 44,
                                            child: Stack(
                                              clipBehavior: Clip.none,
                                              children: [
                                                Container(
                                                  width: 42,
                                                  height: 42,
                                                  decoration: BoxDecoration(
                                                    color: const Color(
                                                      0xFFF6F8FC,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          12,
                                                        ),
                                                    border: Border.all(
                                                      color: const Color(
                                                        0xFFDDE4EF,
                                                      ),
                                                    ),
                                                  ),
                                                  alignment: Alignment.center,
                                                  child: const Icon(
                                                    Icons
                                                        .notifications_none_rounded,
                                                    color: AppColor.textPrimary,
                                                    size: 23,
                                                  ),
                                                ),
                                                if (unread > 0)
                                                  Positioned(
                                                    right: -1,
                                                    top: -3,
                                                    child: Container(
                                                      constraints:
                                                          const BoxConstraints(
                                                            minWidth: 18,
                                                            minHeight: 18,
                                                          ),
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                            horizontal: 4,
                                                          ),
                                                      decoration:
                                                          const BoxDecoration(
                                                            color:
                                                                AppColor.danger,
                                                            shape:
                                                                BoxShape.circle,
                                                          ),
                                                      alignment:
                                                          Alignment.center,
                                                      child: Text(
                                                        unread > 99
                                                            ? '99+'
                                                            : unread.toString(),
                                                        style:
                                                            GoogleFonts.poppins(
                                                              color:
                                                                  Colors.white,
                                                              fontSize: 8,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                            ),
                                                      ),
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ],
                                ),

                                if (hasFamily || showClientSwitch) ...[
                                  const SizedBox(height: 14),

                                  // Family and client switching stay on one line.
                                  Row(
                                    children: [
                                      if (hasFamily)
                                        Expanded(
                                          child: InkWell(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                            onTap: () {
                                              _showFamilySelection(context);
                                            },
                                            child: Container(
                                              height: 46,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 9,
                                                  ),
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFF6F8FC),
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                                border: Border.all(
                                                  color: const Color(
                                                    0xFFDDE4EF,
                                                  ),
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  Container(
                                                    width: 28,
                                                    height: 28,
                                                    decoration:
                                                        const BoxDecoration(
                                                          color: Color(
                                                            0xFF0D4CC9,
                                                          ),
                                                          shape:
                                                              BoxShape.circle,
                                                        ),
                                                    alignment: Alignment.center,
                                                    child: Text(
                                                      _getSafeInitial(
                                                        familyProvider
                                                                .selectedFamily
                                                                ?.name ??
                                                            name,
                                                      ),
                                                      style:
                                                          GoogleFonts.poppins(
                                                            color: Colors.white,
                                                            fontSize: 11,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 7),
                                                  Expanded(
                                                    child: Text(
                                                      'Family Members',
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style:
                                                          GoogleFonts.poppins(
                                                            fontSize: 10.5,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color: AppColor
                                                                .textPrimary,
                                                          ),
                                                    ),
                                                  ),
                                                  const Icon(
                                                    Icons
                                                        .keyboard_arrow_down_rounded,
                                                    size: 18,
                                                    color: Color(0xFF66758B),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),

                                      if (hasFamily && showClientSwitch)
                                        const SizedBox(width: 8),

                                      if (showClientSwitch)
                                        Expanded(
                                          child: InkWell(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                            onTap: () {
                                              _showClientSelection(context);
                                            },
                                            child: Container(
                                              height: 46,
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 9,
                                                  ),
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFF6F8FC),
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                                border: Border.all(
                                                  color: const Color(
                                                    0xFFDDE4EF,
                                                  ),
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  Container(
                                                    width: 28,
                                                    height: 28,
                                                    decoration:
                                                        const BoxDecoration(
                                                          color: Color(
                                                            0xFF082D59,
                                                          ),
                                                          shape:
                                                              BoxShape.circle,
                                                        ),
                                                    alignment: Alignment.center,
                                                    child: Text(
                                                      _getSafeInitial(
                                                        clientSwitchProvider
                                                                .selectedClient
                                                                ?.name ??
                                                            name,
                                                      ),
                                                      style:
                                                          GoogleFonts.poppins(
                                                            color: Colors.white,
                                                            fontSize: 11,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 7),
                                                  Expanded(
                                                    child: Text(
                                                      clientSwitchLabel,
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style:
                                                          GoogleFonts.poppins(
                                                            fontSize: 10.5,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color: AppColor
                                                                .textPrimary,
                                                          ),
                                                    ),
                                                  ),
                                                  const Icon(
                                                    Icons
                                                        .keyboard_arrow_down_rounded,
                                                    size: 18,
                                                    color: Color(0xFF66758B),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ],
                              ],
                            ),
                          );
                        },
                  ),

                  // Compact transition feedback. We intentionally do NOT show
                  // a full-screen loader; the current dashboard remains visible
                  // but the user can clearly see that a different account is
                  // being loaded.
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 180),
                    switchInCurve: Curves.easeOut,
                    switchOutCurve: Curves.easeIn,
                    child: isAccountSwitching
                        ? Container(
                            key: ValueKey(
                              'switching-${clientSwitchState.switchingClientId ?? familySwitchState.switchingFamilyId ?? 0}',
                            ),
                            width: double.infinity,
                            margin: const EdgeInsets.fromLTRB(12, 10, 12, 2),
                            padding: const EdgeInsets.fromLTRB(12, 10, 12, 9),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: AppColor.primary.withValues(alpha: 0.18),
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.04),
                                  blurRadius: 10,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 34,
                                      height: 34,
                                      decoration: BoxDecoration(
                                        color: AppColor.primary.withValues(
                                          alpha: 0.10,
                                        ),
                                        shape: BoxShape.circle,
                                      ),
                                      child: const Icon(
                                        Icons.sync_rounded,
                                        size: 20,
                                        color: AppColor.primary,
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            switchingAccountName.isNotEmpty
                                                ? 'Switching to $switchingAccountName'
                                                : 'Switching account',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: GoogleFonts.poppins(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w600,
                                              color: AppColor.textPrimary,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            switchingAccountCode.isNotEmpty
                                                ? 'Client Code: $switchingAccountCode  •  Updating portfolio'
                                                : 'Updating portfolio data',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: GoogleFonts.poppins(
                                              fontSize: 10.5,
                                              fontWeight: FontWeight.w400,
                                              color: AppColor.textSecondary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: const LinearProgressIndicator(
                                    minHeight: 2.5,
                                    backgroundColor: Color(0xFFE8EEF8),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : const SizedBox.shrink(),
                  ),

                  Expanded(
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 160),
                      opacity: isAccountSwitching ? 0.55 : 1.0,
                      child: IgnorePointer(
                        ignoring: isAccountSwitching,
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 220),
                          switchInCurve: Curves.easeOut,
                          switchOutCurve: Curves.easeIn,
                          child: KeyedSubtree(
                            key: ValueKey(
                              'dashboard-${dashboardData?.activeClientId ?? 0}',
                            ),
                            child: RefreshIndicator(
                              onRefresh: () async {
                                // Refresh the dashboard summary first. The chart refresh
                                // continues independently so the user is not forced to
                                // wait for the heavier chart request.
                                await homeProvider.refreshDashboard(
                                  context,
                                  isRefresh: true,
                                );
                              },
                              child: SingleChildScrollView(
                                physics: const AlwaysScrollableScrollPhysics(),
                                padding: const EdgeInsets.all(8),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _PortfolioCard(),
                                    const SizedBox(height: 16),
                                    // ================================
                                    // BELOW-CHART PORTFOLIO SUMMARY ONLY
                                    // ================================

                                    // Row 1: Realised / Un-Realised
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Container(
                                            constraints: const BoxConstraints(
                                              minHeight: 120,
                                            ),
                                            padding: const EdgeInsets.all(13),
                                            decoration: BoxDecoration(
                                              color:
                                                  AmountUtils.isPositive(
                                                    homeProvider
                                                        .dashboardData
                                                        ?.realised,
                                                  )
                                                  ? const Color(0xFFEFFFF8)
                                                  : const Color(0xFFFFF1F1),
                                              borderRadius:
                                                  BorderRadius.circular(16),
                                              border: Border.all(
                                                color:
                                                    AmountUtils.isPositive(
                                                      homeProvider
                                                          .dashboardData
                                                          ?.realised,
                                                    )
                                                    ? const Color(0xFFA7EBCF)
                                                    : const Color(0xFFFFC5C5),
                                              ),
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  width: 32,
                                                  height: 32,
                                                  decoration: BoxDecoration(
                                                    color:
                                                        AmountUtils.isPositive(
                                                          homeProvider
                                                              .dashboardData
                                                              ?.realised,
                                                        )
                                                        ? const Color(
                                                            0xFF009B72,
                                                          ).withValues(
                                                            alpha: .10,
                                                          )
                                                        : const Color(
                                                            0xFFE53935,
                                                          ).withValues(
                                                            alpha: .10,
                                                          ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          10,
                                                        ),
                                                  ),
                                                  child: Icon(
                                                    AmountUtils.isPositive(
                                                          homeProvider
                                                              .dashboardData
                                                              ?.realised,
                                                        )
                                                        ? Icons
                                                              .trending_up_rounded
                                                        : Icons
                                                              .trending_down_rounded,
                                                    size: 18,
                                                    color:
                                                        AmountUtils.isPositive(
                                                          homeProvider
                                                              .dashboardData
                                                              ?.realised,
                                                        )
                                                        ? const Color(
                                                            0xFF009B72,
                                                          )
                                                        : const Color(
                                                            0xFFE53935,
                                                          ),
                                                  ),
                                                ),
                                                const SizedBox(height: 10),
                                                Text(
                                                  'Realised P&L',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w500,
                                                    color:
                                                        AppColor.textSecondary,
                                                  ),
                                                ),
                                                const SizedBox(height: 2),
                                                FittedBox(
                                                  fit: BoxFit.scaleDown,
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: Text(
                                                    homeProvider
                                                            .dashboardData
                                                            ?.realised ??
                                                        '-',
                                                    maxLines: 1,
                                                    style: GoogleFonts.poppins(
                                                      fontSize: 17,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      color:
                                                          AmountUtils.isPositive(
                                                            homeProvider
                                                                .dashboardData
                                                                ?.realised,
                                                          )
                                                          ? const Color(
                                                              0xFF009B72,
                                                            )
                                                          : const Color(
                                                              0xFFE53935,
                                                            ),
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(height: 2),
                                                Text(
                                                  'Booked profit / loss',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 9,
                                                    color:
                                                        AppColor.textSecondary,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Container(
                                            constraints: const BoxConstraints(
                                              minHeight: 120,
                                            ),
                                            padding: const EdgeInsets.all(13),
                                            decoration: BoxDecoration(
                                              color:
                                                  AmountUtils.isPositive(
                                                    homeProvider
                                                        .dashboardData
                                                        ?.unrealised,
                                                  )
                                                  ? const Color(0xFFEFFFF8)
                                                  : const Color(0xFFFFF1F1),
                                              borderRadius:
                                                  BorderRadius.circular(16),
                                              border: Border.all(
                                                color:
                                                    AmountUtils.isPositive(
                                                      homeProvider
                                                          .dashboardData
                                                          ?.unrealised,
                                                    )
                                                    ? const Color(0xFFA7EBCF)
                                                    : const Color(0xFFFFC5C5),
                                              ),
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  width: 32,
                                                  height: 32,
                                                  decoration: BoxDecoration(
                                                    color:
                                                        AmountUtils.isPositive(
                                                          homeProvider
                                                              .dashboardData
                                                              ?.unrealised,
                                                        )
                                                        ? const Color(
                                                            0xFF009B72,
                                                          ).withValues(
                                                            alpha: .10,
                                                          )
                                                        : const Color(
                                                            0xFFE53935,
                                                          ).withValues(
                                                            alpha: .10,
                                                          ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          10,
                                                        ),
                                                  ),
                                                  child: Icon(
                                                    AmountUtils.isPositive(
                                                          homeProvider
                                                              .dashboardData
                                                              ?.unrealised,
                                                        )
                                                        ? Icons
                                                              .trending_up_rounded
                                                        : Icons
                                                              .trending_down_rounded,
                                                    size: 18,
                                                    color:
                                                        AmountUtils.isPositive(
                                                          homeProvider
                                                              .dashboardData
                                                              ?.unrealised,
                                                        )
                                                        ? const Color(
                                                            0xFF009B72,
                                                          )
                                                        : const Color(
                                                            0xFFE53935,
                                                          ),
                                                  ),
                                                ),
                                                const SizedBox(height: 10),
                                                Text(
                                                  'Un-Realised P&L',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w500,
                                                    color:
                                                        AppColor.textSecondary,
                                                  ),
                                                ),
                                                const SizedBox(height: 2),
                                                FittedBox(
                                                  fit: BoxFit.scaleDown,
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: Text(
                                                    homeProvider
                                                            .dashboardData
                                                            ?.unrealised ??
                                                        '-',
                                                    maxLines: 1,
                                                    style: GoogleFonts.poppins(
                                                      fontSize: 17,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      color:
                                                          AmountUtils.isPositive(
                                                            homeProvider
                                                                .dashboardData
                                                                ?.unrealised,
                                                          )
                                                          ? const Color(
                                                              0xFF009B72,
                                                            )
                                                          : const Color(
                                                              0xFFE53935,
                                                            ),
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(height: 2),
                                                Text(
                                                  'Current market profit / loss',
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 9,
                                                    color:
                                                        AppColor.textSecondary,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),

                                    const SizedBox(height: 10),

                                    // Row 2: Dividend / Net Contribution
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: InkWell(
                                            borderRadius: BorderRadius.circular(
                                              16,
                                            ),
                                            onTap: () {
                                              Navigator.of(context).push(
                                                MaterialPageRoute(
                                                  builder: (_) =>
                                                      const DividendScreen(),
                                                ),
                                              );
                                            },
                                            child: Container(
                                              constraints: const BoxConstraints(
                                                minHeight: 120,
                                              ),
                                              padding: const EdgeInsets.all(13),
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFFFF9E8),
                                                borderRadius:
                                                    BorderRadius.circular(16),
                                                border: Border.all(
                                                  color: const Color(
                                                    0xFFFFD98A,
                                                  ),
                                                ),
                                              ),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    width: 32,
                                                    height: 32,
                                                    decoration: BoxDecoration(
                                                      color: const Color(
                                                        0xFFB66A00,
                                                      ).withValues(alpha: .10),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            10,
                                                          ),
                                                    ),
                                                    child: const Icon(
                                                      Icons
                                                          .currency_rupee_rounded,
                                                      size: 18,
                                                      color: Color(0xFFB66A00),
                                                    ),
                                                  ),
                                                  const SizedBox(height: 10),
                                                  Text(
                                                    'Dividend Income',
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: GoogleFonts.poppins(
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      color: AppColor
                                                          .textSecondary,
                                                    ),
                                                  ),
                                                  const SizedBox(height: 2),
                                                  FittedBox(
                                                    fit: BoxFit.scaleDown,
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: Text(
                                                      homeProvider
                                                              .dashboardData
                                                              ?.dividend ??
                                                          '-',
                                                      maxLines: 1,
                                                      style:
                                                          GoogleFonts.poppins(
                                                            fontSize: 17,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            color: const Color(
                                                              0xFF9C5200,
                                                            ),
                                                          ),
                                                    ),
                                                  ),
                                                  const SizedBox(height: 2),
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: Text(
                                                          'Dividend received',
                                                          maxLines: 1,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: GoogleFonts.poppins(
                                                            fontSize: 9,
                                                            color: AppColor
                                                                .textSecondary,
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(width: 4),
                                                      const Icon(
                                                        Icons
                                                            .arrow_forward_ios_rounded,
                                                        size: 10,
                                                        color: Color(
                                                          0xFF9C5200,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: InkWell(
                                            borderRadius: BorderRadius.circular(
                                              16,
                                            ),
                                            onTap: () {
                                              Navigator.of(context).push(
                                                MaterialPageRoute(
                                                  builder: (_) =>
                                                      const NetContributionScreen(),
                                                ),
                                              );
                                            },
                                            child: Container(
                                              constraints: const BoxConstraints(
                                                minHeight: 120,
                                              ),
                                              padding: const EdgeInsets.all(13),
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFF0F6FF),
                                                borderRadius:
                                                    BorderRadius.circular(16),
                                                border: Border.all(
                                                  color: const Color(
                                                    0xFFBDD6FF,
                                                  ),
                                                ),
                                              ),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    width: 32,
                                                    height: 32,
                                                    decoration: BoxDecoration(
                                                      color: AppColor.primary
                                                          .withValues(
                                                            alpha: .10,
                                                          ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            10,
                                                          ),
                                                    ),
                                                    child: const Icon(
                                                      Icons
                                                          .account_balance_wallet_outlined,
                                                      size: 18,
                                                      color: AppColor.primary,
                                                    ),
                                                  ),
                                                  const SizedBox(height: 10),
                                                  Text(
                                                    'Net Contribution',
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: GoogleFonts.poppins(
                                                      fontSize: 10,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      color: AppColor
                                                          .textSecondary,
                                                    ),
                                                  ),
                                                  const SizedBox(height: 2),
                                                  FittedBox(
                                                    fit: BoxFit.scaleDown,
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: Text(
                                                      homeProvider
                                                              .dashboardData
                                                              ?.netContribution ??
                                                          '-',
                                                      maxLines: 1,
                                                      style:
                                                          GoogleFonts.poppins(
                                                            fontSize: 17,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            color: AppColor
                                                                .primary,
                                                          ),
                                                    ),
                                                  ),
                                                  const SizedBox(height: 2),
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: Text(
                                                          'Net capital contribution',
                                                          maxLines: 1,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: GoogleFonts.poppins(
                                                            fontSize: 9,
                                                            color: AppColor
                                                                .textSecondary,
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(width: 4),
                                                      const Icon(
                                                        Icons
                                                            .arrow_forward_ios_rounded,
                                                        size: 10,
                                                        color: AppColor.primary,
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),

                                    const SizedBox(height: 12),

                                    // Holdings / Gainers / Losers strip
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 13,
                                      ),
                                      decoration: BoxDecoration(
                                        color: AppColor.white,
                                        borderRadius: BorderRadius.circular(16),
                                        border: Border.all(
                                          color: Colors.black.withValues(
                                            alpha: .06,
                                          ),
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.black.withValues(
                                              alpha: .04,
                                            ),
                                            blurRadius: 14,
                                            offset: const Offset(0, 5),
                                          ),
                                        ],
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  width: 30,
                                                  height: 30,
                                                  decoration: BoxDecoration(
                                                    color: const Color(
                                                      0xFF244A7C,
                                                    ).withValues(alpha: .08),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          9,
                                                        ),
                                                  ),
                                                  child: const Icon(
                                                    Icons.layers_outlined,
                                                    size: 17,
                                                    color: Color(0xFF244A7C),
                                                  ),
                                                ),
                                                const SizedBox(height: 5),
                                                Text(
                                                  homeProvider
                                                          .dashboardData
                                                          ?.totalHolding ??
                                                      '-',
                                                  maxLines: 1,
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 17,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColor.textPrimary,
                                                  ),
                                                ),
                                                Text(
                                                  'Holdings',
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 9,
                                                    fontWeight: FontWeight.w500,
                                                    color: const Color(
                                                      0xFF244A7C,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            width: 1,
                                            height: 50,
                                            color: Colors.black.withValues(
                                              alpha: .06,
                                            ),
                                          ),
                                          Expanded(
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  width: 30,
                                                  height: 30,
                                                  decoration: BoxDecoration(
                                                    color: const Color(
                                                      0xFF009B72,
                                                    ).withValues(alpha: .08),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          9,
                                                        ),
                                                  ),
                                                  child: const Icon(
                                                    Icons.trending_up_rounded,
                                                    size: 17,
                                                    color: Color(0xFF009B72),
                                                  ),
                                                ),
                                                const SizedBox(height: 5),
                                                Text(
                                                  homeProvider
                                                          .dashboardData
                                                          ?.totalGainer ??
                                                      '-',
                                                  maxLines: 1,
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 17,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColor.textPrimary,
                                                  ),
                                                ),
                                                Text(
                                                  'Gainers',
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 9,
                                                    fontWeight: FontWeight.w500,
                                                    color: const Color(
                                                      0xFF009B72,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            width: 1,
                                            height: 50,
                                            color: Colors.black.withValues(
                                              alpha: .06,
                                            ),
                                          ),
                                          Expanded(
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  width: 30,
                                                  height: 30,
                                                  decoration: BoxDecoration(
                                                    color: const Color(
                                                      0xFFE53935,
                                                    ).withValues(alpha: .08),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          9,
                                                        ),
                                                  ),
                                                  child: const Icon(
                                                    Icons.trending_down_rounded,
                                                    size: 17,
                                                    color: Color(0xFFE53935),
                                                  ),
                                                ),
                                                const SizedBox(height: 5),
                                                Text(
                                                  homeProvider
                                                          .dashboardData
                                                          ?.totalLoser ??
                                                      '-',
                                                  maxLines: 1,
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 17,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColor.textPrimary,
                                                  ),
                                                ),
                                                Text(
                                                  'Losers',
                                                  style: GoogleFonts.poppins(
                                                    fontSize: 9,
                                                    fontWeight: FontWeight.w500,
                                                    color: const Color(
                                                      0xFFE53935,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    const SizedBox(height: 16),

                                    _MoreOptionsCard(
                                      onHome: widget.onGoHome,
                                      onHoldings: widget.onViewAllHoldings,
                                      onAnalytics: widget.onOpenAnalytics,
                                      onTaxometer: widget.onOpenTaxometer,
                                      onMovers: widget.onOpenMovers,
                                      onProfile: widget.onOpenProfile,
                                    ),

                                    const SizedBox(height: 18),

                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 4,
                                      ),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            'Top Holdings',
                                            style: GoogleFonts.poppins(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w700,
                                              color: AppColor.textPrimary,
                                            ),
                                          ),
                                          const SizedBox(width: 5),
                                          Text(
                                            'By Current Value',
                                            style: GoogleFonts.poppins(
                                              fontSize: 7.5,
                                              fontWeight: FontWeight.w500,
                                              color: AppColor.textSecondary,
                                            ),
                                          ),
                                          const Spacer(),
                                          if (homeProvider
                                              .topHoldings
                                              .isNotEmpty)
                                            InkWell(
                                              borderRadius:
                                                  BorderRadius.circular(18),
                                              onTap: () {
                                                widget.onViewAllHoldings
                                                    ?.call();
                                              },
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                      horizontal: 10,
                                                      vertical: 6,
                                                    ),
                                                decoration: BoxDecoration(
                                                  color: AppColor.primary
                                                      .withValues(alpha: .07),
                                                  borderRadius:
                                                      BorderRadius.circular(18),
                                                ),
                                                child: Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Text(
                                                      'View All (${homeProvider.dashboardData?.totalHolding ?? homeProvider.topHoldings.length})',
                                                      style:
                                                          GoogleFonts.poppins(
                                                            fontSize: 9,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            color: AppColor
                                                                .primary,
                                                          ),
                                                    ),
                                                    const SizedBox(width: 4),
                                                    const Icon(
                                                      Icons
                                                          .arrow_forward_rounded,
                                                      size: 13,
                                                      color: AppColor.primary,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),

                                    const SizedBox(height: 8),

                                    if (homeProvider.topHoldings.isEmpty)
                                      Center(
                                        child: Padding(
                                          padding: const EdgeInsets.all(20),
                                          child: Text(
                                            "No holdings available",
                                            style: GoogleFonts.poppins(),
                                          ),
                                        ),
                                      ),

                                    ...homeProvider.topHoldings.map(
                                      (stock) => _HoldingTile(
                                        holding: stock,
                                        onTap: () {
                                          nextRoute(
                                            MaterialPageRoute(
                                              builder: (context) {
                                                return StockDetailScreen(
                                                  stockId: stock.id.toString(),
                                                );
                                              },
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Future<void> _showFamilySelection(BuildContext context) async {
    final homeProvider = context.read<HomeProvider>();
    final familyProvider = context.read<FamilyProvider>();

    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => const FamilySelectionBottomSheet(),
    );

    if (changed != true) {
      return;
    }

    // If Home disappeared while the selector was closing, never leave a
    // half-finished family user-id switch behind.
    if (!context.mounted) {
      familyProvider.rollbackPendingSwitch();
      return;
    }

    final dashboardLoaded = await homeProvider.refreshDashboard(
      context,
      isRefresh: false,
    );

    if (dashboardLoaded) {
      // The backend confirmed the destination family member.
      familyProvider.confirmPendingSwitch();
      if (context.mounted) {
        context.read<AppNotificationProvider>().getNotifications(
          showLoader: false,
        );
      }
    } else {
      // Keep the previous Dashboard visible and restore the previous user-id.
      familyProvider.rollbackPendingSwitch();
    }
  }

  Future<void> _showClientSelection(BuildContext context) async {
    final homeProvider = context.read<HomeProvider>();
    final clientSwitchProvider = context.read<ClientSwitchProvider>();

    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => const ClientSelectionBottomSheet(),
    );

    if (changed != true) {
      return;
    }

    // If Home disappeared while the selector was closing, never leave a
    // half-finished user-id switch behind.
    if (!context.mounted) {
      clientSwitchProvider.rollbackPendingSwitch();
      return;
    }

    final dashboardLoaded = await homeProvider.refreshDashboard(
      context,
      isRefresh: false,
    );

    if (dashboardLoaded) {
      // The backend confirmed the selected active_client_id.
      clientSwitchProvider.confirmPendingSwitch();
      if (context.mounted) {
        context.read<AppNotificationProvider>().getNotifications(
          showLoader: false,
        );
      }
    } else {
      // Keep the old Dashboard visible and restore the previous user-id.
      clientSwitchProvider.rollbackPendingSwitch();
    }
  }
}

class _MoreOptionsCard extends StatelessWidget {
  final VoidCallback? onHome;
  final VoidCallback? onHoldings;
  final VoidCallback? onAnalytics;
  final VoidCallback? onTaxometer;
  final VoidCallback? onMovers;
  final VoidCallback? onProfile;

  const _MoreOptionsCard({
    this.onHome,
    this.onHoldings,
    this.onAnalytics,
    this.onTaxometer,
    this.onMovers,
    this.onProfile,
  });

  @override
  Widget build(BuildContext context) {
    final items = <_QuickAccessItem>[
      _QuickAccessItem(
        label: 'Home',
        icon: Icons.home_rounded,
        background: const Color(0xFFEAF0FF),
        foreground: AppColor.primary,
        onTap: onHome,
      ),
      _QuickAccessItem(
        label: 'Holdings',
        icon: Icons.account_balance_wallet_rounded,
        background: const Color(0xFFEAF8F2),
        foreground: const Color(0xFF07865F),
        onTap: onHoldings,
      ),
      _QuickAccessItem(
        label: 'Analytics',
        icon: Icons.bar_chart_rounded,
        background: const Color(0xFFF1ECFF),
        foreground: const Color(0xFF6D4BD1),
        onTap: onAnalytics,
      ),
      _QuickAccessItem(
        label: 'Taxometer',
        icon: Icons.speed_rounded,
        background: const Color(0xFFFFF3E5),
        foreground: const Color(0xFFB66A00),
        onTap: onTaxometer,
      ),
      _QuickAccessItem(
        label: 'Movers',
        icon: Icons.trending_up_rounded,
        background: const Color(0xFFEAF8FB),
        foreground: const Color(0xFF087D92),
        onTap: onMovers,
      ),
      _QuickAccessItem(
        label: 'Profile',
        icon: Icons.person_rounded,
        background: const Color(0xFFF5EEF9),
        foreground: const Color(0xFF8B4C9C),
        onTap: onProfile,
      ),
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 13),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE7ECF3)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withValues(alpha: .035),
            blurRadius: 14,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'More Options',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColor.textPrimary,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFF4F7FB),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Quick Access',
                  style: GoogleFonts.poppins(
                    fontSize: 8.5,
                    fontWeight: FontWeight.w500,
                    color: AppColor.textSecondary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          LayoutBuilder(
            builder: (context, constraints) {
              final itemWidth = (constraints.maxWidth - 16) / 3;

              return Wrap(
                spacing: 8,
                runSpacing: 9,
                children: items
                    .map(
                      (item) => SizedBox(
                        width: itemWidth,
                        child: _QuickAccessButton(item: item),
                      ),
                    )
                    .toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _QuickAccessButton extends StatelessWidget {
  final _QuickAccessItem item;

  const _QuickAccessButton({required this.item});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: item.onTap,
        child: Container(
          height: 78,
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 9),
          decoration: BoxDecoration(
            color: const Color(0xFFFAFBFD),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFEEF1F5)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: item.background,
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child: Icon(item.icon, size: 19, color: item.foreground),
              ),
              const SizedBox(height: 6),
              Text(
                item.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(
                  fontSize: 9,
                  height: 1.1,
                  fontWeight: FontWeight.w600,
                  color: AppColor.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickAccessItem {
  final String label;
  final IconData icon;
  final Color background;
  final Color foreground;
  final VoidCallback? onTap;

  const _QuickAccessItem({
    required this.label,
    required this.icon,
    required this.background,
    required this.foreground,
    required this.onTap,
  });
}

class _PortfolioCard extends StatefulWidget {
  const _PortfolioCard();

  @override
  State<_PortfolioCard> createState() => _PortfolioCardState();
}

class _PortfolioCardState extends State<_PortfolioCard> {
  static const List<String> _periods = ['1M', '3M', '1Y', 'MAX'];

  // Chart display selector.
  // NAV is shown by default. Absolute Value keeps using the existing chart API.
  String _chartDisplayMode = 'nav';

  bool get _isNavMode => _chartDisplayMode == 'nav';

  List<int> _getFilteredChartIndexes(HomeProvider provider) {
    final chart = provider.portfolioChartResponse?.data?.chart;

    if (chart == null || chart.dates == null || chart.dates!.isEmpty) {
      return [];
    }

    final values = _isNavMode
        ? (chart.navValues ?? const <double>[])
        : (chart.portfolioValues ?? const <double>[]);

    if (values.isEmpty) {
      return [];
    }

    final dates = chart.dates!;
    final length = dates.length < values.length ? dates.length : values.length;

    if (length <= 0) {
      return [];
    }

    final indexes = List<int>.generate(length, (index) => index);

    if (provider.chartType == 'MAX') {
      return indexes;
    }

    final lastDate = dates[length - 1];
    DateTime cutoff;

    switch (provider.chartType) {
      case '1M':
        cutoff = DateTime(lastDate.year, lastDate.month - 1, lastDate.day);
        break;
      case '3M':
        cutoff = DateTime(lastDate.year, lastDate.month - 3, lastDate.day);
        break;
      case '1Y':
        cutoff = DateTime(lastDate.year - 1, lastDate.month, lastDate.day);
        break;
      default:
        return indexes;
    }

    return indexes.where((index) => !dates[index].isBefore(cutoff)).toList();
  }

  List<double> _getChartValues(HomeProvider provider) {
    final chart = provider.portfolioChartResponse?.data?.chart;
    if (chart == null) return [];

    final values = _isNavMode
        ? (chart.navValues ?? const <double>[])
        : (chart.portfolioValues ?? const <double>[]);

    final indexes = _getFilteredChartIndexes(provider);

    return indexes
        .where((index) => index >= 0 && index < values.length)
        .map((index) => values[index])
        .toList();
  }

  List<FlSpot> _getChartSpots(HomeProvider provider) {
    final values = _getChartValues(provider);

    if (values.isEmpty) {
      return [];
    }

    return List.generate(
      values.length,
      (index) => FlSpot(index.toDouble(), values[index]),
    );
  }

  List<DateTime> _getDates(HomeProvider provider) {
    final chart = provider.portfolioChartResponse?.data?.chart;
    if (chart == null || chart.dates == null) return [];

    final dates = chart.dates!;
    final indexes = _getFilteredChartIndexes(provider);

    return indexes
        .where((index) => index >= 0 && index < dates.length)
        .map((index) => dates[index])
        .toList();
  }

  double _getMinY(List<FlSpot> spots) {
    if (spots.isEmpty) return 0;

    double min = spots.first.y;

    for (final spot in spots) {
      if (spot.y < min) {
        min = spot.y;
      }
    }

    // In NAV mode always keep the Base-100 reference inside the visible range.
    if (_isNavMode && min > 100) {
      min = 100;
    }

    final padding = (min * .05).abs();

    return min - padding;
  }

  double _getMaxY(List<FlSpot> spots) {
    if (spots.isEmpty) return 100;

    double max = spots.first.y;

    for (final spot in spots) {
      if (spot.y > max) {
        max = spot.y;
      }
    }

    // In NAV mode always keep the Base-100 reference inside the visible range.
    if (_isNavMode && max < 100) {
      max = 100;
    }

    final padding = (max * .05).abs();

    return max + padding;
  }

  String _formatAmount(double value) {
    final absValue = value.abs();

    if (absValue >= 10000000) {
      final amount = value / 10000000;

      return amount == amount.roundToDouble()
          ? "${amount.toStringAsFixed(0)}Cr"
          : "${amount.toStringAsFixed(1)}Cr";
    }

    if (absValue >= 100000) {
      final amount = value / 100000;

      return amount == amount.roundToDouble()
          ? "${amount.toStringAsFixed(0)}L"
          : "${amount.toStringAsFixed(1)}L";
    }

    if (absValue >= 1000) {
      final amount = value / 1000;

      return amount == amount.roundToDouble()
          ? "${amount.toStringAsFixed(0)}K"
          : "${amount.toStringAsFixed(1)}K";
    }

    return value.toStringAsFixed(0);
  }

  Widget _leftTitles(
    double value,
    TitleMeta meta,
    double minY,
    double maxY,
    double interval,
  ) {
    final tolerance = interval * 0.30;

    final isMinValue = (value - minY).abs() < 0.0001;
    final isMaxValue = (value - maxY).abs() < 0.0001;

    // fl_chart may insert an interval title immediately beside the
    // forced min/max boundary. Hide only that near-duplicate title.
    // This keeps the intended 5 Y-axis values while preventing overlap.
    if (!isMinValue &&
        !isMaxValue &&
        ((value - minY).abs() < tolerance ||
            (maxY - value).abs() < tolerance)) {
      return const SizedBox.shrink();
    }

    return SideTitleWidget(
      meta: meta,
      space: 0,
      child: Transform.translate(
        // Keep boundary labels comfortably inside the chart.
        offset: isMaxValue
            ? const Offset(0, 3)
            : isMinValue
            ? const Offset(0, -2)
            : Offset.zero,
        child: SizedBox(
          width: 34,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: Text(
              _isNavMode ? value.toStringAsFixed(0) : _formatAmount(value),
              maxLines: 1,
              softWrap: false,
              textAlign: TextAlign.right,
              style: GoogleFonts.poppins(
                color: Colors.white70,
                fontSize: 10,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _bottomTitles(double value, TitleMeta meta, HomeProvider provider) {
    final dates = _getDates(provider);

    final index = value.toInt();

    if (index >= dates.length || index < 0) {
      return const SizedBox();
    }

    final total = dates.length;

    bool show = false;

    switch (provider.chartType) {
      case '1M':
        show = index == 0 || index == total ~/ 2 || index == total - 1;
        break;

      case '3M':
        show =
            index == 0 ||
            index == total ~/ 3 ||
            index == (total * 2) ~/ 3 ||
            index == total - 1;
        break;

      case '1Y':
        show =
            index == 0 ||
            index == total ~/ 4 ||
            index == total ~/ 2 ||
            index == (total * 3) ~/ 4 ||
            index == total - 1;
        break;

      default:
        // MAX / ALL: keep the axis readable even when NAV has daily points.
        show =
            index == 0 ||
            index == total ~/ 4 ||
            index == total ~/ 2 ||
            index == (total * 3) ~/ 4 ||
            index == total - 1;
    }

    if (!show) {
      return const SizedBox();
    }

    final date = dates[index];

    String text;

    switch (provider.chartType) {
      case '1M':
        text = "${date.day} ${_month(date.month)}";
        break;

      case '3M':
        text = "${date.day} ${_month(date.month)}";
        break;

      case '1Y':
        text = _month(date.month);
        break;

      default:
        text = "${_month(date.month)} ${date.year}";
    }

    final isLatestPoint = index == total - 1;
    final now = DateTime.now();
    final isToday =
        date.year == now.year && date.month == now.month && date.day == now.day;

    if (isLatestPoint && isToday) {
      text = "$text (Today)";
    }

    return SideTitleWidget(
      meta: meta,
      space: 8,
      child: Transform.translate(
        // fl_chart centers edge titles on their X coordinate.
        // Move the first and last labels inward so they remain fully visible.
        offset: index == 0
            ? const Offset(20, 0)
            : index == total - 1
            ? const Offset(-42, 0)
            : Offset.zero,
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: isLatestPoint && isToday ? 90 : 58,
          ),
          child: Text(
            text,
            maxLines: 1,
            softWrap: false,
            overflow: TextOverflow.visible,
            textAlign: isLatestPoint
                ? TextAlign.right
                : index == 0
                ? TextAlign.left
                : TextAlign.center,
            style: GoogleFonts.poppins(
              color: isLatestPoint
                  ? const Color(0xFF55F2B0)
                  : const Color(0xFFAAC0D6),
              fontSize: isLatestPoint && isToday ? 9.0 : 9.5,
              fontWeight: isLatestPoint ? FontWeight.w600 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  String _month(int month) {
    const months = [
      '',
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return months[month];
  }

  String _formatInceptionDate(String? rawDate) {
    final value = (rawDate ?? '').trim();

    if (value.isEmpty) {
      return '';
    }

    final parts = value.split('-');

    if (parts.length == 3) {
      final day = int.tryParse(parts[0]);
      final month = int.tryParse(parts[1]);
      final year = int.tryParse(parts[2]);

      if (day != null &&
          month != null &&
          month >= 1 &&
          month <= 12 &&
          year != null) {
        return "$day ${_month(month)} $year";
      }
    }

    return value;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<HomeProvider>(
      builder: (context, provider, child) {
        final dashboard = provider.dashboardData;
        final spots = _getChartSpots(provider);
        final dates = _getDates(provider);

        final chartMinY = _getMinY(spots);
        final chartMaxY = _getMaxY(spots);

        // 4 gaps = 5 Y-axis values.
        final interval = ((chartMaxY - chartMinY) / 4).abs();

        const mint = Color(0xFF55F2B0);
        const lossRed = Color(0xFFFF5C64);
        const cardTop = Color(0xFF071D3E);
        const cardBottom = Color(0xFF123C8E);
        const softText = Color(0xFFAAC0D6);

        final todayAmount = dashboard?.todaysGainLoss ?? "0";
        final totalAmount = dashboard?.totalGainLoss ?? "0";
        final netContributionAmount = (dashboard?.netContribution ?? "0")
            .toAmount();
        final totalGainLossPercentage = netContributionAmount > 0
            ? (totalAmount.toAmount() / netContributionAmount) * 100
            : 0.0;
        final isTodayGain = todayAmount.toAmount() >= 0;
        final isTotalGain = totalAmount.toAmount() >= 0;
        final inceptionDate = _formatInceptionDate(
          dashboard?.oldestVoucherDate,
        );

        Widget gainPanel({
          required String title,
          required String amount,
          required bool isGain,
          String? percentage,
        }) {
          final valueColor = isGain ? mint : lossRed;

          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: .075),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.white.withValues(alpha: .12),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.poppins(
                    color: softText,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    Icon(
                      isGain
                          ? Icons.arrow_drop_up_rounded
                          : Icons.arrow_drop_down_rounded,
                      size: 18,
                      color: valueColor,
                    ),
                    const SizedBox(width: 1),
                    Expanded(
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          amount,
                          maxLines: 1,
                          style: GoogleFonts.poppins(
                            color: valueColor,
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            height: 1.05,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                if ((percentage ?? '').isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Padding(
                    padding: const EdgeInsets.only(left: 19),
                    child: Text(
                      percentage!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.poppins(
                        color: valueColor.withValues(alpha: .92),
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          );
        }

        Widget chartModeButton({required String value, required String label}) {
          final selected = _chartDisplayMode == value;

          return Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () {
                if (selected) return;

                // NAV and Absolute Value are both included in the same
                // portfolio-chart-full response. Switching display mode is a
                // local UI operation and must never trigger another API call.
                setState(() {
                  _chartDisplayMode = value;
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                curve: Curves.easeOut,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                decoration: BoxDecoration(
                  color: selected ? Colors.white : Colors.transparent,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: selected
                      ? [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: .08),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ]
                      : null,
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    label,
                    maxLines: 1,
                    style: GoogleFonts.poppins(
                      color: selected ? const Color(0xFF1745C8) : softText,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
          );
        }

        return Container(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [cardTop, cardBottom],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: Colors.white.withValues(alpha: .08),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF071D3E).withValues(alpha: .28),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Compact header, inspired by the supplied reference.
              Row(
                children: [
                  Text(
                    "PORTFOLIO VALUE",
                    style: GoogleFonts.poppins(
                      color: const Color(0xFFD6E4F1),
                      fontSize: 9.5,
                      fontWeight: FontWeight.w700,
                      letterSpacing: .35,
                    ),
                  ),
                  const SizedBox(width: 5),
                  const Icon(
                    Icons.lock_outline_rounded,
                    size: 12,
                    color: Color(0xFFAAC0D6),
                  ),
                  const Spacer(),
                  if (inceptionDate.isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: .095),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: .08),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.calendar_month_outlined,
                            size: 12,
                            color: softText,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            "Since $inceptionDate",
                            style: GoogleFonts.poppins(
                              color: softText,
                              fontSize: 8.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),

              const SizedBox(height: 10),

              // Portfolio value + XIRR chip.
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(
                        dashboard?.portfolioValue ?? "₹0",
                        maxLines: 1,
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -.6,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 7,
                    ),
                    decoration: BoxDecoration(
                      color: mint.withValues(alpha: .13),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: mint.withValues(alpha: .30)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.trending_up_rounded,
                          size: 15,
                          color: mint,
                        ),
                        const SizedBox(width: 4),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "XIRR",
                              style: GoogleFonts.poppins(
                                color: mint,
                                fontSize: 8.5,
                                fontWeight: FontWeight.w700,
                                height: 1.0,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "${dashboard?.xirr ?? 0}%",
                              style: GoogleFonts.poppins(
                                color: mint,
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700,
                                height: 1.0,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 14),

              // Today's Gain/Loss and Total Gain/Loss are intentionally
              // placed directly above the chart-mode toggle.
              Row(
                children: [
                  Expanded(
                    child: gainPanel(
                      title: "Today's Gain/Loss",
                      amount: todayAmount,
                      isGain: isTodayGain,
                      percentage:
                          "${(dashboard?.todaysGainLossPercentage ?? 0) >= 0 ? '+' : ''}"
                          "${(dashboard?.todaysGainLossPercentage ?? 0).toStringAsFixed(2)}%",
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: gainPanel(
                      title: "Total Gain/Loss",
                      amount: totalAmount,
                      isGain: isTotalGain,
                      percentage:
                          "${totalGainLossPercentage >= 0 ? '+' : ''}"
                          "${totalGainLossPercentage.toStringAsFixed(2)}%",
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 10),

              // NAV / Absolute Value toggle from the supplied reference.
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF0F6).withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: .08),
                  ),
                ),
                child: Row(
                  children: [
                    chartModeButton(value: 'nav', label: "NAV (Time-Weighted)"),
                    const SizedBox(width: 3),
                    chartModeButton(value: 'absolute', label: "Absolute Value"),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              // Performance track + compact period selector.
              Row(
                children: [
                  Text(
                    "Performance Track",
                    style: GoogleFonts.poppins(
                      color: const Color(0xFFD6E4F1),
                      fontSize: 9.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .12),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: _periods.map((period) {
                        final selected = provider.chartType == period;

                        return GestureDetector(
                          onTap: () {
                            if (selected) return;

                            // Full history is already loaded by the separate
                            // background chart API, so every period change is
                            // instant and local for NAV and Absolute Value.
                            provider.updateChartTypeLocally(period);
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 160),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 9,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: selected
                                  ? Colors.white
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(7),
                            ),
                            child: Text(
                              period,
                              style: GoogleFonts.poppins(
                                color: selected
                                    ? const Color(0xFF1745C8)
                                    : softText,
                                fontSize: 8.5,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              // Existing real chart data/behavior retained; only visual styling
              // is updated to match the dark navy + mint reference.
              SizedBox(
                height: 205,
                child: spots.isEmpty
                    ? Center(
                        child: provider.portfolioChartLoading
                            ? const CircularProgressIndicator(color: mint)
                            : Text(
                                "No chart data available",
                                style: GoogleFonts.poppins(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                      )
                    : LineChart(
                        LineChartData(
                          minX: 0,
                          maxX: (spots.length - 1).toDouble(),
                          minY: chartMinY,
                          maxY: chartMaxY,
                          borderData: FlBorderData(show: false),
                          gridData: FlGridData(
                            show: true,
                            drawVerticalLine: false,
                            horizontalInterval: interval == 0 ? 1 : interval,
                            getDrawingHorizontalLine: (value) {
                              return FlLine(
                                color: Colors.white.withValues(alpha: .10),
                                strokeWidth: 1,
                                dashArray: [4, 4],
                              );
                            },
                          ),
                          extraLinesData: ExtraLinesData(
                            horizontalLines: _isNavMode
                                ? [
                                    HorizontalLine(
                                      y: 100,
                                      color: softText.withValues(alpha: .45),
                                      strokeWidth: 1,
                                      dashArray: [5, 5],
                                    ),
                                  ]
                                : const [],
                          ),
                          titlesData: FlTitlesData(
                            topTitles: const AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            rightTitles: const AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            leftTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                reservedSize: 38,
                                interval: interval == 0 ? 1 : interval,

                                // Keep both boundaries so the chart continues
                                // to show 5 Y-axis values.
                                minIncluded: true,
                                maxIncluded: true,

                                // If fl_chart generates a normal interval title
                                // very close to a boundary title, hide only that
                                // duplicate. The actual min/max values stay.
                                getTitlesWidget: (value, meta) => _leftTitles(
                                  value,
                                  meta,
                                  chartMinY,
                                  chartMaxY,
                                  interval == 0 ? 1 : interval,
                                ),
                              ),
                            ),
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                reservedSize: 30,
                                getTitlesWidget: (value, meta) =>
                                    _bottomTitles(value, meta, provider),
                              ),
                            ),
                          ),
                          lineTouchData: LineTouchData(
                            enabled: true,
                            handleBuiltInTouches: true,
                            touchTooltipData: LineTouchTooltipData(
                              fitInsideHorizontally: true,
                              fitInsideVertically: true,
                              getTooltipItems: (spots) {
                                return spots.map((spot) {
                                  final index = spot.x.toInt();

                                  if (index >= dates.length) {
                                    return LineTooltipItem(
                                      _isNavMode
                                          ? "NAV: ${spot.y.toStringAsFixed(2)}"
                                          : "₹${spot.y.toStringAsFixed(0)}",
                                      GoogleFonts.poppins(
                                        color: Colors.white,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    );
                                  }

                                  final date = dates[index];

                                  return LineTooltipItem(
                                    "${date.day} ${_month(date.month)} ${date.year}\n"
                                    "${_isNavMode ? 'NAV: ${spot.y.toStringAsFixed(2)}' : '₹${spot.y.toStringAsFixed(0)}'}",
                                    GoogleFonts.poppins(
                                      color: Colors.white,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  );
                                }).toList();
                              },
                            ),
                            getTouchedSpotIndicator: (barData, indexes) {
                              return indexes.map((index) {
                                return TouchedSpotIndicatorData(
                                  FlLine(
                                    color: mint.withValues(alpha: .25),
                                    strokeWidth: 1,
                                  ),
                                  FlDotData(
                                    getDotPainter: (spot, percent, bar, index) {
                                      return FlDotCirclePainter(
                                        radius: 5,
                                        color: Colors.white,
                                        strokeWidth: 2,
                                        strokeColor: mint,
                                      );
                                    },
                                  ),
                                );
                              }).toList();
                            },
                          ),
                          lineBarsData: [
                            LineChartBarData(
                              spots: spots,
                              isCurved: true,
                              curveSmoothness: .32,
                              color: mint,
                              barWidth: 2.6,
                              isStrokeCapRound: true,
                              dotData: FlDotData(
                                show: true,
                                checkToShowDot: (spot, barData) {
                                  return spot.x == spots.length - 1;
                                },
                                getDotPainter: (spot, percent, barData, index) {
                                  return FlDotCirclePainter(
                                    radius: 4,
                                    color: Colors.white,
                                    strokeWidth: 2,
                                    strokeColor: mint,
                                  );
                                },
                              ),
                              belowBarData: BarAreaData(
                                show: true,
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    mint.withValues(alpha: .22),
                                    mint.withValues(alpha: .08),
                                    Colors.transparent,
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _HoldingTile extends StatelessWidget {
  final TopHolding holding;
  final VoidCallback onTap;

  const _HoldingTile({required this.holding, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final gainPercent = holding.gainPercent ?? 0;
    final isGain = gainPercent >= 0;
    final gainColor = isGain
        ? const Color(0xFF009B72)
        : const Color(0xFFE53935);

    final todayPercent = holding.todaysPercentage ?? 0;
    final isTodayGain = todayPercent >= 0;
    final todayColor = isTodayGain
        ? const Color(0xFF009B72)
        : const Color(0xFFE53935);

    final assetName = (holding.assetName ?? '').trim();
    final initials = getInitials(assetName);

    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.fromLTRB(12, 11, 12, 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE6EBF2), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .045),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Company name + total gain percentage
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: AppColor.primary,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  alignment: Alignment.center,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Text(
                        initials,
                        maxLines: 1,
                        style: GoogleFonts.poppins(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    assetName,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColor.textPrimary,
                      height: 1.15,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: gainColor.withValues(alpha: .09),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${isGain ? '+' : '-'}${gainPercent.abs().toStringAsFixed(1)}%',
                        style: GoogleFonts.poppins(
                          fontSize: 8.5,
                          fontWeight: FontWeight.w700,
                          color: gainColor,
                        ),
                      ),
                      const SizedBox(width: 2),
                      Icon(
                        isGain
                            ? Icons.arrow_drop_up_rounded
                            : Icons.arrow_drop_down_rounded,
                        size: 14,
                        color: gainColor,
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 9),

            Divider(height: 1, thickness: 1, color: const Color(0xFFF0F2F6)),

            const SizedBox(height: 9),

            // Today's P&L / Invested / Current Value
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _valueColumn(
                    label: "Today's P&L",
                    value: (holding.todays ?? '').isNotEmpty
                        ? holding.todays!
                        : '-',
                    valueColor: todayColor,
                    subValue:
                        '${todayPercent >= 0 ? '+' : ''}${todayPercent.toStringAsFixed(2)}%',
                    subColor: todayColor,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _valueColumn(
                    label: 'Invested',
                    value: (holding.investedValue ?? '').isNotEmpty
                        ? holding.investedValue!
                        : '-',
                    valueColor: AppColor.textPrimary,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _valueColumn(
                    label: 'Current Value',
                    value: (holding.currentValue ?? '').isNotEmpty
                        ? holding.currentValue!
                        : '-',
                    valueColor: AppColor.textPrimary,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _valueColumn({
    required String label,
    required String value,
    required Color valueColor,
    String? subValue,
    Color? subColor,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: GoogleFonts.poppins(
            fontSize: 7.5,
            fontWeight: FontWeight.w500,
            color: AppColor.textSecondary,
          ),
        ),
        const SizedBox(height: 3),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(
            value,
            maxLines: 1,
            style: GoogleFonts.poppins(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: valueColor,
            ),
          ),
        ),
        if ((subValue ?? '').isNotEmpty) ...[
          const SizedBox(height: 1),
          Text(
            subValue!,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.poppins(
              fontSize: 7.5,
              fontWeight: FontWeight.w500,
              color: subColor ?? AppColor.textSecondary,
            ),
          ),
        ],
      ],
    );
  }
}
