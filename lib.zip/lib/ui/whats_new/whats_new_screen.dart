import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:profit_from_it_investors/model/whats_new_response.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:profit_from_it_investors/ui/dashboard_screen/dashboard_screen.dart';
import 'package:profit_from_it_investors/ui/notifications/notifications_screen.dart';
import 'package:profit_from_it_investors/ui/support_messages/support_messages_screen.dart';
import 'package:profit_from_it_investors/utility/app_color.dart';

class WhatsNewScreen extends StatelessWidget {
  const WhatsNewScreen({super.key, required WhatsNewRelease release, required String currentVersion, required String currentBuild, required bool isLoggedIn});

  static const String versionLabel = '1.1.8';

  // Vimeo test ID. Replace only this value with your own Vimeo video ID.
  static const String supportMessagesVimeoVideoId = '1239718100';

  void _continueToDashboard(BuildContext context) {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const DashboardScreen()),
      (route) => false,
    );
  }

  void _openSupport(BuildContext context) {
    Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (_) => const SupportMessagesScreen()));
  }

  void _openNotifications(BuildContext context) {
    Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (_) => const NotificationsScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final updates = <_WhatsNewItem>[
      _WhatsNewItem(
        badge: 'NEW',
        title: 'Support Messages',
        description:
            'Raise support tickets, follow replies, and keep your support conversations together inside the app.',
        icon: Icons.forum_rounded,
        accent: const Color(0xFF2563EB),
        soft: const Color(0xFFEFF6FF),
        buttonText: 'Explore Support',
        onTap: () => _openSupport(context),
        vimeoVideoId: supportMessagesVimeoVideoId,
      ),
      _WhatsNewItem(
        badge: 'IMPROVED',
        title: 'Smarter Notifications',
        description:
            'Review important account and portfolio notifications faster with a cleaner experience.',
        icon: Icons.notifications_active_rounded,
        accent: const Color(0xFF7C3AED),
        soft: const Color(0xFFF5F3FF),
        buttonText: 'View Notifications',
        onTap: () => _openNotifications(context),
      ),
      _WhatsNewItem(
        badge: 'REFINED',
        title: 'Performance & UI Improvements',
        description:
            'Cleaner screens, smoother navigation, performance improvements, and important bug fixes.',
        icon: Icons.auto_awesome_rounded,
        accent: const Color(0xFFEA580C),
        soft: const Color(0xFFFFF7ED),
      ),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 22),
                children: [
                  const _HeaderCard(),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'What’s new',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: AppColor.textPrimary,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEFF6FF),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text(
                          '${updates.length} highlights',
                          style: GoogleFonts.poppins(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                            color: AppColor.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'A quick look at the latest improvements.',
                    style: GoogleFonts.poppins(
                      fontSize: 10.5,
                      color: AppColor.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 14),
                  ...updates.map(
                    (item) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _UpdateCard(item: item),
                    ),
                  ),
                ],
              ),
            ),
            _ContinueBar(onContinue: () => _continueToDashboard(context)),
          ],
        ),
      ),
    );
  }
}

class _HeaderCard extends StatelessWidget {
  const _HeaderCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0B2DAA), Color(0xFF1649D8), Color(0xFF2563EB)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(26),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0D3CCF).withOpacity(.18),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -35,
            top: -45,
            child: Container(
              width: 135,
              height: 135,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(.07),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.12),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.auto_awesome_rounded,
                          size: 14,
                          color: Colors.white,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'NEW UPDATE',
                          style: GoogleFonts.poppins(
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Text(
                    'v${WhatsNewScreen.versionLabel}',
                    style: GoogleFonts.poppins(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: Colors.white.withOpacity(.78),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              Text(
                'What’s New',
                style: GoogleFonts.poppins(
                  fontSize: 29,
                  height: 1.05,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'A smarter investor experience',
                style: GoogleFonts.poppins(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  color: Colors.white.withOpacity(.88),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.10),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Explore the latest features and improvements',
                  style: GoogleFonts.poppins(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w600,
                    color: Colors.white.withOpacity(.88),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _UpdateCard extends StatelessWidget {
  final _WhatsNewItem item;

  const _UpdateCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE6EBF2)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withOpacity(.035),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: item.soft,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Icon(item.icon, color: item.accent, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: item.soft,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Text(
                    item.badge,
                    style: GoogleFonts.poppins(
                      fontSize: 8,
                      letterSpacing: .45,
                      fontWeight: FontWeight.w800,
                      color: item.accent,
                    ),
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  item.title,
                  style: GoogleFonts.poppins(
                    fontSize: 14.5,
                    height: 1.3,
                    fontWeight: FontWeight.w700,
                    color: AppColor.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  item.description,
                  style: GoogleFonts.poppins(
                    fontSize: 10.6,
                    height: 1.6,
                    color: AppColor.textSecondary,
                  ),
                ),
                if (item.vimeoVideoId != null) ...[
                  const SizedBox(height: 14),
                  _SupportVimeoPlayer(
                    videoId: item.vimeoVideoId!,
                    accent: item.accent,
                  ),
                ],
                if (item.onTap != null) ...[
                  const SizedBox(height: 12),
                  Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton(
                      onPressed: item.onTap,
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: item.soft,
                        foregroundColor: item.accent,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 13,
                          vertical: 10,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        item.buttonText ?? 'Explore',
                        style: GoogleFonts.poppins(
                          fontSize: 9.7,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SupportVimeoPlayer extends StatefulWidget {
  final String videoId;
  final Color accent;

  const _SupportVimeoPlayer({required this.videoId, required this.accent});

  @override
  State<_SupportVimeoPlayer> createState() => _SupportVimeoPlayerState();
}

class _SupportVimeoPlayerState extends State<_SupportVimeoPlayer> {
  late final WebViewController _controller;
  bool _isLoading = true;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();

    final playerUrl = Uri.parse(
      'https://player.vimeo.com/video/${widget.videoId}'
      '?title=0&byline=0&portrait=0&dnt=1&playsinline=1',
    );

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _isLoading = true;
              _hasError = false;
            });
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() {
              _isLoading = false;
            });
          },
          onWebResourceError: (error) {
            if (!mounted) return;

            // Ignore sub-resource errors. Only mark the main frame as failed.
            if (error.isForMainFrame == true) {
              setState(() {
                _isLoading = false;
                _hasError = true;
              });
            }
          },
        ),
      )
      ..loadRequest(playerUrl);
  }

  @override
  Widget build(BuildContext context) {
    if (widget.videoId.trim().isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF7ED),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFFED7AA)),
        ),
        child: Text(
          'Add a Vimeo video ID first.',
          style: GoogleFonts.poppins(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            color: const Color(0xFF9A3412),
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withOpacity(.08),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Stack(
              fit: StackFit.expand,
              children: [
                WebViewWidget(controller: _controller),
                if (_isLoading)
                  const ColoredBox(
                    color: Colors.black,
                    child: Center(
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    ),
                  ),
                if (_hasError)
                  ColoredBox(
                    color: const Color(0xFF0F172A),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.error_outline_rounded,
                              color: Colors.white,
                              size: 30,
                            ),
                            const SizedBox(height: 10),
                            Text(
                              'Unable to load Vimeo video.',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.poppins(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextButton(
                              onPressed: () {
                                setState(() {
                                  _isLoading = true;
                                  _hasError = false;
                                });

                                _controller.reload();
                              },
                              child: const Text('Retry'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            child: Row(
              children: [
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: widget.accent.withOpacity(.10),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.play_circle_fill_rounded,
                    size: 18,
                    color: widget.accent,
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    'Watch how Support Messages works',
                    style: GoogleFonts.poppins(
                      fontSize: 9.8,
                      fontWeight: FontWeight.w600,
                      color: AppColor.textPrimary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ContinueBar extends StatelessWidget {
  final VoidCallback onContinue;

  const _ContinueBar({required this.onContinue});

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Container(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 12 + bottomPadding),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: Color(0xFFE6EBF2))),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0F172A).withOpacity(.05),
            blurRadius: 16,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SizedBox(
        width: double.infinity,
        height: 50,
        child: ElevatedButton(
          onPressed: onContinue,
          style: ElevatedButton.styleFrom(
            elevation: 0,
            backgroundColor: AppColor.primary,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Continue to App',
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 7),
              const Icon(Icons.arrow_forward_rounded, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}

class _WhatsNewItem {
  final String badge;
  final String title;
  final String description;
  final IconData icon;
  final Color accent;
  final Color soft;
  final String? buttonText;
  final VoidCallback? onTap;
  final String? vimeoVideoId;

  const _WhatsNewItem({
    required this.badge,
    required this.title,
    required this.description,
    required this.icon,
    required this.accent,
    required this.soft,
    this.buttonText,
    this.onTap,
    this.vimeoVideoId,
  });
}
