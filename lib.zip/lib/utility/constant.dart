class Constants {
  static const String baseUrl = "https://investors.profitfromit.co.in";
  static const String apiUrl = "$baseUrl/api/";
  static const String appName = "Profit From It Investors";

  static const String playStoreUrl = "";
  static const String appStoreUrl = "";

  static const String copyRightMessage =
      "© 2026 — PROFIT FINSTOCK PRIVATE LIMITED. All Rights Reserved.";
}

class CMD {
  static const String login = "login";
  static const String logout = "logout";
  static const String otpVerification = "otp-verification";
  static const String otpReSend = "otp-resend";
  static const String getProfile = "profile";
  static const String dashboard = "dashboard";

  // Public app update/version check.
  static const String appVersion = "app-version";

  static const String netContributionDetails = "net-contribution-details";
  static const String dividendDetails = "dividend-details";
  static const String clientImpersonate = "client/impersonate";
  static const String clientImpersonateStop = "client/impersonate/stop";
  static const String stockDetail = "stock-detail";
  static const String holdings = "holdings";
  static const String analytics = "analytics";
  static const String taxometer = "taxometer";
  static const String transactions = "transactions";
  static const String topMovers = "top-movers";
  static const String portfolioChart = "portfolio-chart";
  static const String portfolioChartFull = "portfolio-chart-full";
  static const String deleteAccount = "delete-account";
}
